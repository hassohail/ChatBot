Python 3.10 or higher version should be installed in pc.

Commands to run in Terminal or Command prompt:
pip install flask
pip install spacy fuzzywuzzy python-Levenshtein
pip install json


Then open the folder Rammas Chatbot in vscode or in cmd:
and type this command to run the project on localhost.

python mypy.py

OR

python3 mypy.py


then it will give you the link of the running project, which look like this:
http://localhost:5000

then paste this link on your browser and enjoy the chatbot.

Thanks