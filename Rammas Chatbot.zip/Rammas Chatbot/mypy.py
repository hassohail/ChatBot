from flask import Flask, request, render_template
import json
from fuzzywuzzy import fuzz

app = Flask(__name__)

# Read the question and answer pairs from the text file
def read_qa_pairs(file_path):
    qa_pairs = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.strip()
            if line:
                question, answer = line.split('|')
                qa_pairs.append((question.strip(), answer.strip()))
    return qa_pairs

# Function to find the closest matching question
def find_matching_question(user_question, qa_pairs):
    best_match_score = 0
    best_match_question = None

    # Check if the user question is a single keyword or contains a grammar mistake
    if len(user_question.split()) == 1:
        print("Bot: Please provide a more specific question.")
        # return "Please provide a more specific question."
    
    for question, _ in qa_pairs:
        match_score = calculate_match_score(user_question, question)
        if match_score > best_match_score:
            best_match_score = match_score
            best_match_question = question

    # Set a threshold for match score (adjust as per your requirement)
    threshold = 80
    print(best_match_score)
    if best_match_score >= threshold:
        return best_match_question
    else:
        print("Bot: I'm sorry, I couldn't understand your question. Please try again.")
        # return "I'm sorry, I couldn't understand your question. Please try again."

# Function to calculate match score between user question and dataset question
def calculate_match_score(user_question, dataset_question):
    user_keywords = extract_keywords(user_question)
    dataset_keywords = extract_keywords(dataset_question)

    match_score = fuzz.token_set_ratio(user_keywords, dataset_keywords)
    return match_score

# Function to extract keywords from a question
def extract_keywords(question):
    # Define your keyword extraction logic here
    # Example: You can use regular expressions or NLP techniques to extract keywords
    # Modify this function based on your specific requirements

    keywords = question.lower().split()  # Split the question into lowercase words
    # stopwords = ['a', 'an', 'the', 'in', 'on', 'at', 'is', 'are', 'was', 'were', 'to', 'for']  # Define your stopwords
    stopwords = [
    'a', 'ain', 'an', 'and', 'any', 'are', 'aren', "aren't", 'as',
    'at', 'be', 'because', 'been', 'before', 'being', 'below', 'between', 'both', 'but', 'by', 'can',
    'd', 'did', 'didn', "didn't", 'do', 'does', 'doesn', "doesn't", 'doing', 'don', "don't", 'down', 'during', 'each', 'few',
    'further', 'had', 'hadn', "hadn't", 'has', 'hasn', "hasn't", 'have', 'haven', "haven't", 'having', 'he',
    'her', 'here', 'hers', 'herself', 'him', 'himself', 'his', 'i', 'if', 'in',
    "it's", 'its', 'itself', 'just', 'll', 'm', 'ma', 'me', 'mightn', "mightn't", 'more', 'most', 'mustn', "mustn't", 'my',
    'myself', 'needn', "needn't", 'no', 'nor', 'now', 'o', 'off', 'once', 'only', 'or', 'other',
    'over', 'own', 're', 's', 'she', "she's", 'so', 'some', 'such', 't', 'than', 'that', "that'll", 'theirs', 'them',
    'themselves', 'then', 'this', 'those', 'to', 'too', 'under', 'up', 've',
    'very', 'wasn', "wasn't", 'we', 'were', 'weren', "weren't", 'when', 'where', 'which', 'while',
    'whom', 'will', 'won', "won't", 'y'
    ]

    keywords = [keyword for keyword in keywords if keyword not in stopwords]  # Remove stopwords
    print(keywords)
    # Check for plural forms and singularize the keywords
    singular_keywords = []
    for keyword in keywords:
        if keyword not in stopwords:
            if keyword.endswith('s'):
                singular_keyword = keyword[:-1]  # Remove 's' from the end of the word
                singular_keywords.append(singular_keyword)
            else:
                singular_keywords.append(keyword)

    return " ".join(singular_keywords)  # Return the extracted keywords as a string

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/answer')
# Main program
def main():
    file_path = 'cbs_qa.txt'  # Path to your question and answer file
    qa_pairs = read_qa_pairs(file_path)

    user_question = str(request.args.get('question'))+"?"

    matching_question = find_matching_question(user_question, qa_pairs)

    if matching_question:
        # Retrieve the answer corresponding to the matching question
        answer = next(answer for question, answer in qa_pairs if question == matching_question)
        # print("Bot:", answer)
        # camel_case_text = ''.join([word.capitalize() if i > 0 and random.random() < 0.5 else word.lower() for i, word in enumerate(answer)])
        json_dump = json.dumps(answer)
        return json_dump
    else:
        return json.dumps("I'm sorry, I don't have an answer for that.<br> Please provide a more specific question.")

if __name__ == '__main__':
    app.run()
