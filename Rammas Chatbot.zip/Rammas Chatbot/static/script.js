// The code handles the value of an input element. 
// It trims any whitespace, logs the trimmed value, and passes it to the output function if it's not empty.
function sendMenu(element){
    var menuValue=element.value;
    console.log(menuValue);
    // const menu = document.getElementById("input");
    let menu = menuValue.trim();
    console.log(menu)
    // It checks if menu is not an empty string. If it's not empty, it calls the output function and passes menu as an argument.
    menu!= "" && output(menu);
    menuValue.value = "";
  }
  
  
  function sendMessage() {
    // Get the input field element with the ID "input" and assign it to the variable inputField.
    const inputField = document.getElementById("input");
    // Trim any leading or trailing whitespace from the value of the inputField and assign it to the variable input.
    let input = inputField.value.trim();
    // Check if the input is not an empty string and if true, call the function output with the input as an argument.
    input != "" && output(input);
    // Set the value of the inputField to an empty string.
    inputField.value = "";
  }
  document.addEventListener("DOMContentLoaded", () => {
    // When the DOM content is loaded, execute the following code:
    // Get the input field element with the ID "input" and assign it to the variable inputField.
    const inputField = document.getElementById("input");
    // Add an event listener to the inputField for the "keydown" event.
    inputField.addEventListener("keydown", function (e) {
      // When a key is pressed down in the inputField, execute the following code:
      // Check if the pressed key's code is equal to "Enter".
      if (e.code === "Enter") {
        // Trim any leading or trailing whitespace from the value of the inputField and assign it to the variable input.
        let input = inputField.value.trim();
        // Check if the input is not an empty string and if true, call the function output with the input as an argument.
        input != "" && output(input);
        // Set the value of the inputField to an empty string.
        inputField.value = "";
      }
    });
  });
  
  function output(input) {
    // It calls another function called addChat and passes the input as an argument.
    addChat(input);
  }
  

// This code defines a JavaScript function called "addChat" that is triggered when a user sends an input. It uses an XMLHttpRequest object to send a GET request to a specific endpoint ("/answer") with the user's input as a query parameter. The function then handles the response received from the server.

// The response is parsed as JSON, and based on the value of the input, different actions are taken. If the input matches specific conditions (e.g., "Consumer," "Builder," "Supplier"), corresponding messages and menu buttons are dynamically created and appended to the HTML document. Each submenu has its own set of buttons with specific values and onclick event handlers.

// The code also includes conditionals for different submenu options, such as "Local Purchase," "Tenders," "GITEX Technology Week 2022," "Amazon Alexa," "Inflation Allowance," and "EV Green Charger." For each submenu option, appropriate messages and buttons are created and added to the document.

// Overall, the code handles user inputs, sends requests to a server, receives responses, and dynamically updates the user interface by creating message elements and menu buttons based on the received data.
  
  function addChat(input) {
  
      var xhr = new XMLHttpRequest();
      xhr.open("GET", "/answer?question="+input);
      xhr.setRequestHeader("Content-Type", "application/json");
  
      xhr.onload = function() {
      if (xhr.status === 200) {
          var responseData = JSON.parse(xhr.responseText);
  
          // menu Consumer
          if(input=="Consumer"){
            const mainDiv = document.getElementById("message-section");
            let userDiv = document.createElement("div");
            userDiv.id = "user";
            userDiv.classList.add("message");
            userDiv.innerHTML = `<span id="user-response">${input}</span>`;
            mainDiv.appendChild(userDiv);
  
            let botDiv = document.createElement("div");
            botDiv.id = "bot";
            botDiv.classList.add("message");
            botDiv.innerHTML = `<span id="bot-response">You may select from "Consumer" submenu</span>`;
            mainDiv.appendChild(botDiv);
            let menuButtons=document.createElement("div");
            menuButtons.id="menuButtons";
            menuButtons.innerHTML=`
            <button class="btn" id="menuBtn" value="GITEX Technology Week 2022" onclick="sendMenu(this)" >GITEX Technology Week 2022</button>
            <button class="btn" id="menuBtn" value="Amazon Alexa" onclick="sendMenu(this)" >Amazon Alexa</button>
            <button class="btn" id="menuBtn" value="Inflation Allowance" onclick="sendMenu(this)" >Inflation Allowance</button>
            <button class="btn" id="menuBtn" value="EV Green Charger" onclick="sendMenu(this)" >EV Green Charger</button>    <br><br><br>
            `
            mainDiv.appendChild(menuButtons)
            var scroll = document.getElementById("message-section");
            scroll.scrollTop = scroll.scrollHeight;
          }
  
          // menu Builder
          else if(input=="Builder"){
            const mainDiv = document.getElementById("message-section");
            let userDiv = document.createElement("div");
            userDiv.id = "user";
            userDiv.classList.add("message");
            userDiv.innerHTML = `<span id="user-response">${input}</span>`;
            mainDiv.appendChild(userDiv);
  
            let botDiv = document.createElement("div");
            botDiv.id = "bot";
            botDiv.classList.add("message");
            botDiv.innerHTML = `<span id="bot-response">You may select from "Builder" submenu</span>`;
            mainDiv.appendChild(botDiv);
            let menuButtons=document.createElement("div");
            menuButtons.id="menuButtons";
            menuButtons.innerHTML=`
            <button class="btn" id="menuBtn" value="Shams Dubai - General" onclick="sendMenu(this)" >Shams Dubai - General</button>
            <button class="btn" id="menuBtn" value="Shams Dubai - Consultant and Contractors" onclick="sendMenu(this)" >Shams Dubai - Consultant and Contractors</button> 
            <button class="btn" id="menuBtn" value="Shams Dubai - Solar PV Expert Certification" onclick="sendMenu(this)" >Shams Dubai - Solar PV Expert Certification</button> 
            <button class="btn" id="menuBtn" value="Shams Dubai - Eligibility" onclick="sendMenu(this)" >Shams Dubai - Eligibility</button> 
            <br><br><br>
            `
            mainDiv.appendChild(menuButtons)
            var scroll = document.getElementById("message-section");
            scroll.scrollTop = scroll.scrollHeight;
          }
  
          // Supplier
          else if(input=="Supplier"){
            const mainDiv = document.getElementById("message-section");
            let userDiv = document.createElement("div");
            userDiv.id = "user";
            userDiv.classList.add("message");
            userDiv.innerHTML = `<span id="user-response">${input}</span>`;
            mainDiv.appendChild(userDiv);
  
            let botDiv = document.createElement("div");
            botDiv.id = "bot";
            botDiv.classList.add("message");
            botDiv.innerHTML = `<span id="bot-response">You may select from "Supplier" submenu</span>`;
            mainDiv.appendChild(botDiv);
            let menuButtons=document.createElement("div");
            menuButtons.id="menuButtons";
            menuButtons.innerHTML=`
            <button class="btn" id="menuBtn" value="Local Purchase" onclick="sendMenu(this)" >Local Purchase</button>
            <button class="btn" id="menuBtn" value="Tenders" onclick="sendMenu(this)" >Tenders</button> 
            <br><br><br>
            `
            mainDiv.appendChild(menuButtons)
            var scroll = document.getElementById("message-section");
            scroll.scrollTop = scroll.scrollHeight;
          }


          // Local Purchase
          else if(input=="Local Purchase"){
            const mainDiv = document.getElementById("message-section");
            let userDiv = document.createElement("div");
            userDiv.id = "user";
            userDiv.classList.add("message");
            userDiv.innerHTML = `<span id="user-response">${input}</span>`;
            mainDiv.appendChild(userDiv);
  
            let botDiv = document.createElement("div");
            botDiv.id = "bot";
            botDiv.classList.add("message");
            botDiv.innerHTML = `<span id="bot-response">You may select from "Local Purchase" submenu</span>`;
            mainDiv.appendChild(botDiv);
            let menuButtons=document.createElement("div");
            menuButtons.id="menuButtons";
            menuButtons.innerHTML=`
            <button class="btn" id="menuBtn" value="How can I submit online quotation" onclick="sendMenu(this)" >How can I submit online quotation?</button>
            <button class="btn" id="menuBtn" value="Can I modify my quotation after submitting" onclick="sendMenu(this)" >Can I modify my quotation after submitting?</button> 
            <br><br><br>
            `
            mainDiv.appendChild(menuButtons)
            var scroll = document.getElementById("message-section");
            scroll.scrollTop = scroll.scrollHeight;
          }


          // Tenders
          else if(input=="Tenders"){
            const mainDiv = document.getElementById("message-section");
            let userDiv = document.createElement("div");
            userDiv.id = "user";
            userDiv.classList.add("message");
            userDiv.innerHTML = `<span id="user-response">${input}</span>`;
            mainDiv.appendChild(userDiv);
  
            let botDiv = document.createElement("div");
            botDiv.id = "bot";
            botDiv.classList.add("message");
            botDiv.innerHTML = `<span id="bot-response">You may select from "Tenders" submenu</span>`;
            mainDiv.appendChild(botDiv);
            let menuButtons=document.createElement("div");
            menuButtons.id="menuButtons";
            menuButtons.innerHTML=`
            <button class="btn" id="menuBtn" value="How to submit a tender online" onclick="sendMenu(this)" >How to submit a tender online?</button>
            <button class="btn" id="menuBtn" value="How do I purchase the tender" onclick="sendMenu(this)" >How do I purchase the tender?</button> 
            <br><br><br>
            `
            mainDiv.appendChild(menuButtons)
            var scroll = document.getElementById("message-section");
            scroll.scrollTop = scroll.scrollHeight;
          }



          // GITEX Technology Week 2022
          else if(input=="GITEX Technology Week 2022"){
            const mainDiv = document.getElementById("message-section");
            let userDiv = document.createElement("div");
            userDiv.id = "user";
            userDiv.classList.add("message");
            userDiv.innerHTML = `<span id="user-response">${input}</span>`;
            mainDiv.appendChild(userDiv);
  
            let botDiv = document.createElement("div");
            botDiv.id = "bot";
            botDiv.classList.add("message");
            botDiv.innerHTML = `<span id="bot-response">You may select from "GITEX Technology Week" submenu</span>`;
            mainDiv.appendChild(botDiv);
            let menuButtons=document.createElement("div");
            menuButtons.id="menuButtons";
            menuButtons.innerHTML=`
            <button class="btn" id="menuBtn" value="What is the role of Dubai Electricity and Water Authority (DEWA) in GITEX Technology Week" onclick="sendMenu(this)" >What is the role of (DEWA) in GITEX Technology Week?</button>
            <button class="btn" id="menuBtn" value="Where will DEWA stand be located" onclick="sendMenu(this)" >Where will DEWA stand be located?</button> 
            <br><br><br>
            `
            mainDiv.appendChild(menuButtons)
            var scroll = document.getElementById("message-section");
            scroll.scrollTop = scroll.scrollHeight;
          }
  
  
          // Amazon Alexa
          else if(input=="Amazon Alexa"){
            const mainDiv = document.getElementById("message-section");
            let userDiv = document.createElement("div");
            userDiv.id = "user";
            userDiv.classList.add("message");
            userDiv.innerHTML = `<span id="user-response">${input}</span>`;
            mainDiv.appendChild(userDiv);
  
            let botDiv = document.createElement("div");
            botDiv.id = "bot";
            botDiv.classList.add("message");
            botDiv.innerHTML = `<span id="bot-response">You may select from "Amazon Alexa" submenu</span>`;
            mainDiv.appendChild(botDiv);
            let menuButtons=document.createElement("div");
            menuButtons.id="menuButtons";
            menuButtons.innerHTML=`
            <button class="btn" id="menuBtn" value="Why is DEWA Skill available on Amazon Alexa" onclick="sendMenu(this)" >Why is DEWA Skill available on Amazon Alexa</button>
            <button class="btn" id="menuBtn" value="How can I download DEWA Skill on Amazon Alexa" onclick="sendMenu(this)" >How can I download DEWA Skill on Amazon Alexa</button> 
            <br><br><br>
            `
            mainDiv.appendChild(menuButtons)
            var scroll = document.getElementById("message-section");
            scroll.scrollTop = scroll.scrollHeight;
          }
  
  
          // Inflation Allowance
          else if(input=="Inflation Allowance"){
            const mainDiv = document.getElementById("message-section");
            let userDiv = document.createElement("div");
            userDiv.id = "user";
            userDiv.classList.add("message");
            userDiv.innerHTML = `<span id="user-response">${input}</span>`;
            mainDiv.appendChild(userDiv);
  
            let botDiv = document.createElement("div");
            botDiv.id = "bot";
            botDiv.classList.add("message");
            botDiv.innerHTML = `<span id="bot-response">You may select from "Inflation Allowance" submenu</span>`;
            mainDiv.appendChild(botDiv);
            let menuButtons=document.createElement("div");
            menuButtons.id="menuButtons";
            menuButtons.innerHTML=`
            <button class="btn" id="menuBtn" value="What is the Inflation Allowance?" onclick="sendMenu(this)" >What is the Inflation Allowance</button>
            <button class="btn" id="menuBtn" value="What is the amount of Inflation on DEWA Electricity & Water Consumption" onclick="sendMenu(this)" >What is the amount of Inflation allowance on DEWA Electricity & Water Consumption</button> 
            <br><br><br>
            `
            mainDiv.appendChild(menuButtons)
            var scroll = document.getElementById("message-section");
            scroll.scrollTop = scroll.scrollHeight;
          }
  
  
          // EV Green Charger
          else if(input=="EV Green Charger"){
            const mainDiv = document.getElementById("message-section");
            let userDiv = document.createElement("div");
            userDiv.id = "user";
            userDiv.classList.add("message");
            userDiv.innerHTML = `<span id="user-response">${input}</span>`;
            mainDiv.appendChild(userDiv);
  
            let botDiv = document.createElement("div");
            botDiv.id = "bot";
            botDiv.classList.add("message");
            botDiv.innerHTML = `<span id="bot-response">You may select from "EV Green Charger" submenu</span>`;
            mainDiv.appendChild(botDiv);
            let menuButtons=document.createElement("div");
            menuButtons.id="menuButtons";
            menuButtons.innerHTML=`
            <button class="btn" id="menuBtn" value="What is The Electric Vehicle (EV) Green Charger" onclick="sendMenu(this)" >What is The Electric Vehicle (EV) Green Charger</button>
            <button class="btn" id="menuBtn" value="Since the launch of the initiative in 2015, what progress has been made so far" onclick="sendMenu(this)" >Since the launch of the initiative in 2015, what progress has been made so far</button> 
            <br><br><br>
            `
            mainDiv.appendChild(menuButtons)
            var scroll = document.getElementById("message-section");
            scroll.scrollTop = scroll.scrollHeight;
          }
  
          // Shams Dubai - General
          else if(input=="Shams Dubai - General"){
            const mainDiv = document.getElementById("message-section");
            let userDiv = document.createElement("div");
            userDiv.id = "user";
            userDiv.classList.add("message");
            userDiv.innerHTML = `<span id="user-response">${input}</span>`;
            mainDiv.appendChild(userDiv);
  
            let botDiv = document.createElement("div");
            botDiv.id = "bot";
            botDiv.classList.add("message");
            botDiv.innerHTML = `<span id="bot-response">You may select from "Shams Dubai - General" submenu</span>`;
            mainDiv.appendChild(botDiv);
            let menuButtons=document.createElement("div");
            menuButtons.id="menuButtons";
            menuButtons.innerHTML=`
            <button class="btn" id="menuBtn" value='What are photovoltaic (solar) systems or "PV"' onclick="sendMenu(this)" >What are photovoltaic (solar) systems or "PV"</button>
            <button class="btn" id="menuBtn" value="How does our society collectively benefit from this" onclick="sendMenu(this)" >How does our society collectively benefit from this</button> 
            <br><br><br>
            `
            mainDiv.appendChild(menuButtons)
            var scroll = document.getElementById("message-section");
            scroll.scrollTop = scroll.scrollHeight;
          }
  
  
          // Shams Dubai - Consultant and Contractors
          else if(input=="Shams Dubai - Consultant and Contractors"){
            const mainDiv = document.getElementById("message-section");
            let userDiv = document.createElement("div");
            userDiv.id = "user";
            userDiv.classList.add("message");
            userDiv.innerHTML = `<span id="user-response">${input}</span>`;
            mainDiv.appendChild(userDiv);
  
            let botDiv = document.createElement("div");
            botDiv.id = "bot";
            botDiv.classList.add("message");
            botDiv.innerHTML = `<span id="bot-response">You may select from "Shams Dubai - Consultant and Contractors" submenu</span>`;
            mainDiv.appendChild(botDiv);
            let menuButtons=document.createElement("div");
            menuButtons.id="menuButtons";
            menuButtons.innerHTML=`
            <button class="btn" id="menuBtn" value='Why does DEWA require an enrolment process' onclick="sendMenu(this)" >Why does DEWA require an enrolment process</button>
            <button class="btn" id="menuBtn" value="How can my company apply for enrolment" onclick="sendMenu(this)" >How can my company apply for enrolment</button> 
            <br><br><br>
            `
            mainDiv.appendChild(menuButtons)
            var scroll = document.getElementById("message-section");
            scroll.scrollTop = scroll.scrollHeight;
          }
  
  
          // Shams Dubai - Solar PV Expert Certification
          else if(input=="Shams Dubai - Solar PV Expert Certification"){
            const mainDiv = document.getElementById("message-section");
            let userDiv = document.createElement("div");
            userDiv.id = "user";
            userDiv.classList.add("message");
            userDiv.innerHTML = `<span id="user-response">${input}</span>`;
            mainDiv.appendChild(userDiv);
  
            let botDiv = document.createElement("div");
            botDiv.id = "bot";
            botDiv.classList.add("message");
            botDiv.innerHTML = `<span id="bot-response">You may select from "Shams Dubai - Solar PV Expert Certification" submenu</span>`;
            mainDiv.appendChild(botDiv);
            let menuButtons=document.createElement("div");
            menuButtons.id="menuButtons";
            menuButtons.innerHTML=`
            <button class="btn" id="menuBtn" value='What is the purpose of the Solar PV Expert Certification' onclick="sendMenu(this)" >What is the purpose of the Solar PV Expert Certification</button>
            <button class="btn" id="menuBtn" value="What does this certification process entail" onclick="sendMenu(this)" >What does this certification process entail</button> 
            <br><br><br>
            `
            mainDiv.appendChild(menuButtons)
            var scroll = document.getElementById("message-section");
            scroll.scrollTop = scroll.scrollHeight;
          }
  
  
          // Shams Dubai - Eligibility
          else if(input=="Shams Dubai - Eligibility"){
            const mainDiv = document.getElementById("message-section");
            let userDiv = document.createElement("div");
            userDiv.id = "user";
            userDiv.classList.add("message");
            userDiv.innerHTML = `<span id="user-response">${input}</span>`;
            mainDiv.appendChild(userDiv);
  
            let botDiv = document.createElement("div");
            botDiv.id = "bot";
            botDiv.classList.add("message");
            botDiv.innerHTML = `<span id="bot-response">You may select from "Shams Dubai - Eligibility" submenu</span>`;
            mainDiv.appendChild(botDiv);
            let menuButtons=document.createElement("div");
            menuButtons.id="menuButtons";
            menuButtons.innerHTML=`
            <button class="btn" id="menuBtn" value='Can only individuals apply for the certification or can also companies apply' onclick="sendMenu(this)" >Can only individuals apply for the certification or can also companies apply</button>
            <button class="btn" id="menuBtn" value="How can I nominate employees for the DEWA PV training" onclick="sendMenu(this)" >How can I nominate employees for the DEWA PV training</button> 
            <br><br><br>
            `
            mainDiv.appendChild(menuButtons)
            var scroll = document.getElementById("message-section");
            scroll.scrollTop = scroll.scrollHeight;
          }
  
  
         
  
          else{
            // Clear the tbody element
            // document.querySelector('tbody').innerHTML = "";
            const mainDiv = document.getElementById("message-section");
            let userDiv = document.createElement("div");
            userDiv.id = "user";
            userDiv.classList.add("message");
            userDiv.innerHTML = `<span id="user-response">${input}</span>`;
            mainDiv.appendChild(userDiv);
  
            let botDiv = document.createElement("div");
            botDiv.id = "bot";
            botDiv.classList.add("message");
            botDiv.innerHTML = `<span id="bot-response">${responseData}</span>`;
            mainDiv.appendChild(botDiv);
  
            let menuButtons=document.createElement("div");
            menuButtons.id="menuButtons";
            menuButtons.innerHTML=`
            <button class="btn" id="menuBtn" value="Consumer" onclick="sendMenu(this)" >Consumer</button>
            <button class="btn" id="menuBtn" value="Builder" onclick="sendMenu(this)">Builder</button>
            <button class="btn" id="menuBtn" value="Supplier" onclick="sendMenu(this)">Supplier</button>
            <br><br><br>
            `
            mainDiv.appendChild(menuButtons)
  
            var scroll = document.getElementById("message-section");
            scroll.scrollTop = scroll.scrollHeight;
          }
      } 
      else {
          console.error("Request failed with status:", xhr.status);
      }
  };
  
  xhr.send();
  }
  
  
  // The resetChat function is responsible for resetting the chat interface to its initial state
  function resetChat()
  {
    const mainDiv = document.getElementById("message-section");
    // Clear the content of the main message section
    mainDiv.innerHTML="";
    // Create menu buttons and initial bot message
    let menuButtons=document.createElement("div");
    menuButtons.id="menuButtons";
    menuButtons.innerHTML=`
    <div class="message" id="bot"><span id="bot-response">Hi, I am Rammas, the virtual assistant from DEWA, available around the clock 24/7. For any inquiry, please type your question or select from below
    </span></div>
    <button class="btn" id="menuBtn" value="Consumer" onclick="sendMenu(this)" >Consumer</button>
    <button class="btn" id="menuBtn" value="Builder" onclick="sendMenu(this)">Builder</button>
    <button class="btn" id="menuBtn" value="Supplier" onclick="sendMenu(this)">Supplier</button>
    <br><br>
    <span style="background-color: #000;color: white; padding: 0.8%;border-radius: 8px;">Quick Services</span>
    <br><br>
    <button class="btn" id="menuBtn" value="What is the role of Dubai Electricity and Water Authority (DEWA) in GITEX Technology Week?" onclick="sendMenu(this)" >Role of DEWA in GITEX Technology Week</button>
    <button class="btn" id="menuBtn" value="Why is DEWA Skill available on Amazon Alexa?" onclick="sendMenu(this)" >Why is DEWA Skill available on Amazon Alexa?</button>  
    <button class="btn" id="menuBtn" value='What are photovoltaic (solar) systems or "PV"?' onclick="sendMenu(this)" >What are photovoltaic (solar) systems or "PV"?</button>  
    <button class="btn" id="menuBtn" value="How can I find out about a purchase enquiry" onclick="sendMenu(this)" >How can I find out about a purchase enquiry?</button><br> <br><br> 
    `
    // Append menu buttons to the main message section
    mainDiv.appendChild(menuButtons)

    // Scroll to the bottom of the main message section
    var scroll = document.getElementById("message-section");
    scroll.scrollTop = scroll.scrollHeight;
  }
  